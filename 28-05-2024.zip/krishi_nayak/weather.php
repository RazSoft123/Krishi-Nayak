<?php

$url = 'https://api.openweathermap.org/data/3.0/onecall?lat=25.09&lon=85.31&exclude=hourly,daily&appid=d46d1f376b83302d794797cea3a3c4a6'; 
$response = file_get_contents($url);

if ($response) {
  // Process the response (e.g., decode JSON)
  $data = json_decode($response, true);
  echo "API response: ";
  print_r($data);
} else {
  echo "Error: Could not retrieve data from API.";
}

?>