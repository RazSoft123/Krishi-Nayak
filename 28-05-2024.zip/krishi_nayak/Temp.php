<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>

  <script>
    function callme(value) {
      if(value == true){
        alert("Printed value is true");
      }
      if(value == false){
        alert("Print value is false");
      }
    }
  </script>

  <style>
    div{
      width:200px;
      height:200px;
      background-color:red;
    }
  </style>

</head>
<body>
  
  <?php

    echo "<div onclick='callme(".'0'.")'>
    </div>"
  ?>

</body>
</html>
<?php

/*
    echo "THis is working";

    // Establishing connection with the mysql database to list the all database tables. 
    $servername = "localhost";
    $username = "root";
    $password = "";
    //$dbname = "your_database";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    echo "Connected successfully <br/>";
    echo "List of database on the server<br/>";

    $query = "show databases";
    $result = mysqli_query($conn, $query);

    if(!$result){
        echo "Error ".$result;
    }

    //Showing the number of rows
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          echo $row["Database"];
          echo "<br/>";
        }
      } else {
        echo "No records found.";
      }

    // Close connection (example)
    mysqli_close($conn);

      */

    //Checking if we are able to call a javascript funton with boolean value in from php code



    ?>