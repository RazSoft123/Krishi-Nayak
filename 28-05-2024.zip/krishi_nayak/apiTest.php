<?php
    $url = 'https://api.data.gov.in/catalog/f67a0294-b0c2-48a1-b6f7-00fcad8ada78?api-key=579b464db66ec23bdd00000189cda08e61824b467e449716c53022d5&format=xml';

    $curl = curl_init($url);
    $responce = curl_exec($curl);
    $curl_error = curl_error($curl);
    curl_close($curl);

    if ($responce){
        echo "Responce ".$responce;
    }else {
        echo "error".$curl_error;
    }
?>